'''
This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org>

Dependent Modules
=================

This code is using the dependencies
above and beyond the Python standard library.
Please refer to LICENCE file.
'''

import bpy
from bpy.types import Header
from bpy.types import Panel
import bpy.utils.previews
from bpy.types import AddonPreferences
from bpy.types import PropertyGroup
from bpy.props import PointerProperty
from bpy.props import BoolProperty
from bpy.props import IntProperty
from bpy.props import FloatProperty
from bpy.props import StringProperty
from bpy.props import EnumProperty
from bpy.props import FloatVectorProperty
from bpy.app.handlers import persistent
from bl_ui.properties_paint_common import UnifiedPaintPanel

import os

status_screenshot = ""
status_render = ""

preview_collections = {}
icon_value_imgur = 0
icon_value_dropbox = 0
icon_value_gdrive = 0
icon_value_twitter = 0
icon_value_gif = 0
gdrive_account = ""
twitter_account = ""
dropbox_account = ""
authorize_url = ""

screenpainting = False
screenpaint_scene = None

reloading = False

GIFs_status = ""


# Load all icons
def load_icons():

    pcoll_icons = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),"icons")
    pcoll_icons.load("imgur", os.path.join(icons_dir, "imgur.png"), 'IMAGE')
    pcoll_icons.load("dropbox", os.path.join(icons_dir, "dropbox.png"), 'IMAGE')
    pcoll_icons.load("gdrive", os.path.join(icons_dir, "gdrive.png"), 'IMAGE')
    pcoll_icons.load("twitter", os.path.join(icons_dir, "twitter.png"), 'IMAGE')
    pcoll_icons.load("gif", os.path.join(icons_dir, "gif.png"), 'IMAGE')
    preview_collections["icons"] = pcoll_icons
    get_icon_values()

    userinfo_path = os.path.join(os.path.dirname(__file__), "user_info")
    linked_accs_path = os.path.join(userinfo_path, "linked_accounts.json")
    if not os.path.isfile(linked_accs_path):
        import json
        json_data = {}
        json_data["User Settings"] = {}
        with open(linked_accs_path, 'w') as outfile:
            json.dump(json_data, outfile)

# Get the icon values
def get_icon_values():
    global icon_value_imgur
    global icon_value_dropbox
    global icon_value_gdrive
    global icon_value_twitter
    global icon_value_gif

    icon_value_imgur = preview_collections["icons"]["imgur"].icon_id
    icon_value_dropbox = preview_collections["icons"]["dropbox"].icon_id
    icon_value_gdrive = preview_collections["icons"]["gdrive"].icon_id
    icon_value_twitter = preview_collections["icons"]["twitter"].icon_id
    icon_value_gif = preview_collections["icons"]["gif"].icon_id


@persistent
def load_json(scene):
    # Import stuff
    import json
    global dropbox_account
    global gdrive_account
    global twitter_account
    global reloading
    reloading = True

    userinfo_path = os.path.join(os.path.dirname(__file__), "user_info")
    if not os.path.exists(userinfo_path):
        os.makedirs(userinfo_path)

    # Read the Json
    json_data = {}
    json_path = os.path.join(userinfo_path, "user_settings.json")
    linked_accs_path = os.path.join(userinfo_path, "linked_accounts.json")
    if os.path.isfile(json_path):
        with open(json_path,'r') as infile:
            json_data = json.load(infile)
    else:
        json_data["User Settings"] = {}
        with open(json_path, 'w') as outfile:
            json.dump(json_data, outfile)

    for prop in json_data["User Settings"]:
        val = 'bpy.context.scene.blendshare.'+prop+ '= json_data["User Settings"]["' + prop + '"]'
        exec(val)

    # Gdrive
#    gdrive_store = os.path.join(os.path.dirname(__file__), "user_info", "Storage.json")
    linked_accs_data = {}
    if os.path.isfile(linked_accs_path):
        with open(linked_accs_path,'r') as infile:
            linked_accs_data = json.load(infile)
    else:
        linked_accs_data["Dropbox"] = {"linked_account":""}
        linked_accs_data["GDrive"] = {"linked_account":""}
        linked_accs_data["Twitter"] = {"linked_account":""}
        with open(linked_accs_path, 'w') as outfile:
            json.dump(linked_accs_data, outfile)
    try:
        gdrive_account = linked_accs_data["GDrive"]["linked_account"]
    except:
        gdrive_account = ""
    try:
        dropbox_account = linked_accs_data["Dropbox"]["linked_account"]
    except:
        dropbox_account = ""
    try:
        twitter_account = linked_accs_data["Twitter"]["linked_account"]
    except:
        twitter_account = ""

    reloading = False


# Runs these at start at start
load_icons()
ik = "91381"
# UV/Image Editor header
class INFO_Header_BlendShare(Header):
    bl_space_type = 'INFO'
    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        props = bpy.context.scene.blendshare

        if GIFs_status == "post":
            row.label("Upload GIF to:", icon_value=icon_value_gif)
            row.operator("scene.blendshare_upload_gif",text="",icon_value=icon_value_imgur).upload_type = "imgur"
            row.operator("scene.blendshare_upload_gif",text="",icon_value=icon_value_dropbox).upload_type = "dropbox"
            row.operator("scene.blendshare_upload_gif",text="",icon_value=icon_value_gdrive).upload_type = "gdrive"
            row.operator("scene.blendshare_twitter_upload_gif",text="",icon_value=icon_value_twitter)
            row.operator("scene.blendshare_upload_gif",text="Cancel",icon="CANCEL").upload_type = "cancel"
        elif GIFs_status == "rec":
            row.operator("scene.blendshare_record_gif", text="Stop Recording", icon_value=icon_value_gif)
        elif bpy.context.scene.blendshare.UI_show_screenshot:
            if props.use_imgur:
                row.operator("scene.blendshare_imgur_screenshot",icon_value=icon_value_imgur, text="")#,emboss=False) # Imgur
            #row.operator("scene.blendshare_dropbox_upload",icon_value=icon_value_dropbox, text="",emboss=False) # Only for now, offline use
            if (props.use_dropbox and (props.dropbox_server_desktop == "SERVER" and dropbox_account != ""))\
                or (props.use_dropbox and (props.dropbox_server_desktop == "DESKTOP" and props.dropbox_desktop_path != "")):
                row.operator("scene.blendshare_dropbox_screenshot",icon_value=icon_value_dropbox, text="")#,emboss=False)
            if props.use_gdrive and gdrive_account != "":
                row.operator("scene.blendshare_gdrive_screenshot",icon_value=icon_value_gdrive, text="")
            if twitter_account != "" and props.use_twitter:
                row.operator("scene.blendshare_twitter_screenshot",icon_value=icon_value_twitter, text="")
            row.operator("scene.blendshare_screenshot_draw",icon="BRUSH_DATA",text="")
            row.operator("scene.blendshare_record_gif",text="",icon_value=icon_value_gif)
            #row.label(status_screenshot)


# Info header
class IMAGE_EDITOR_Header_BlendShare(Header):
    bl_space_type = 'IMAGE_EDITOR'
    def draw(self, context):
        layout = self.layout
        layout.separator()
        props = bpy.context.scene.blendshare
        row = layout.row(align=True)
        # Get all icon values
        #imgur = preview_collections["icons"]["imgur"].icon_id


        if props.UI_show_render:
            if props.UI_restrict_render and (bpy.context.area.spaces.active.image == None or bpy.context.area.spaces.active.image.type != "RENDER_RESULT"):
                return
            if props.use_imgur:
                row.operator("scene.blendshare_imgur_upload",icon_value=icon_value_imgur, text="")#,emboss=False) # Imgur
            if (props.use_dropbox and (props.dropbox_server_desktop == "SERVER" and dropbox_account != ""))\
                or (props.use_dropbox and (props.dropbox_server_desktop == "DESKTOP" and props.dropbox_desktop_path != "")):
                row.operator("scene.blendshare_dropbox_upload",icon_value=icon_value_dropbox, text="")#,emboss=False)
            if props.use_gdrive and gdrive_account != "":
                row.operator("scene.blendshare_gdrive_upload",icon_value=icon_value_gdrive, text="")
            if twitter_account != "" and props.use_twitter:
                row.operator("scene.blendshare_twitter_upload",icon_value=icon_value_twitter, text="")

class BrushButtonsPanel(UnifiedPaintPanel):
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'TOOLS'

    @classmethod
    def poll(cls, context):
        sima = context.space_data
        toolsettings = context.tool_settings.image_paint
        return sima.show_paint and toolsettings.brush
dk = "e5c9bz"

class Screenshot_Draw(BrushButtonsPanel,Panel):
    bl_idname = "Screenshot_Draw"
    bl_label = "BlendShare"
    bl_category = "Tools"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'TOOLS'

    @classmethod
    def poll(cls, context):
        return screenpainting

    def draw(self, context):
        layout = self.layout
        props = bpy.context.scene.blendshare
        scene = context.scene
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(props, "crop_mode",icon="STICKY_UVS_VERT",expand=True)
        #row.operator("scene.blendshare_screenshot_crop",icon="STICKY_UVS_VERT")
        if "Crop" in bpy.context.area.spaces.active.image.name:
            row.operator("scene.blendshare_screenshot_crop_undo",icon="LOOP_BACK",text="")
        col.separator()
        col.operator("scene.blendshare_screenshot_draw_clear",icon="IMAGE_COL")
        col.separator()
        if props.use_imgur:
            col.operator("scene.blendshare_screenshot_draw_upload",icon_value=icon_value_imgur, text="Upload to Imgur").upload_type = "imgur"
        if (props.use_dropbox and (props.dropbox_server_desktop == "SERVER" and dropbox_account != ""))\
            or (props.use_dropbox and (props.dropbox_server_desktop == "DESKTOP" and props.dropbox_desktop_path != "")):
            col.operator("scene.blendshare_screenshot_draw_upload",icon_value=icon_value_dropbox, text="Upload to Dropbox").upload_type = "dropbox"
        if gdrive_account != "" and props.use_gdrive:
            col.operator("scene.blendshare_screenshot_draw_upload",icon_value=icon_value_gdrive, text="Upload to Google Drive").upload_type = "gdrive"
        if twitter_account != "" and props.use_twitter:
            col.operator("scene.blendshare_screenshot_draw_upload",icon_value=icon_value_twitter, text="Tweet image").upload_type = "twitter"
        col.separator()
        col.operator("scene.blendshare_screenshot_draw_cancel",text="Cancel",icon="CANCEL")


class pl_studio_preferences(AddonPreferences):
    bl_idname = __package__
    #scriptdir = bpy.path.abspath(os.path.dirname(__file__))
    def draw(self, context):
        props = context.scene.blendshare
        layout = self.layout

        col = layout.column()
        row = col.row()

        if not props.UI_tab_General:
            row.prop(props, "UI_tab_General",icon="TRIA_RIGHT")
            #row.label("User Interface:")
        else:
            row.prop(props, "UI_tab_General",icon="TRIA_DOWN")
            #row.label("User Interface:")
            box = col.box()

            # Action Settings

            col = box.column()
            col.label("Action after uploading is complete:")
            row = col.row()
            row.prop(props,"use_copy_clipboard")
            row.prop(props,"use_open_browser")

            # Gifs
            box.separator()
            col = box.column()
            col.label("Animated GIFs:")
            row = col.row()
            row.prop(props, "gifs_speed")
            row.prop(props, "gifs_playback")
            row = col.row().split(.495)
            row.prop(props, "wait_timer")

            # Copy

            box.separator()
            col = box.column()
            col.label("Local Copy:")
            row = col.row().split(.25)
            row.prop(props,"use_save_copy")
            subrow = row.row(align=True).split(.75)
            subrow.enabled = props.use_save_copy
            subrow.prop(props,"save_copy_dir",text="")
            subrow.prop(props,"copy_file_ext",text="", icon="IMAGE_DATA")
            col = box.column(align=True).split(.25)
            col.enabled = props.use_save_copy
            col.label("")
            col.prop(props,"copy_only_render")



        # Imgur Settings
        col = layout.column()
        if not props.UI_tab_imgur:
            col.prop(props, "UI_tab_imgur",icon="TRIA_RIGHT")
        else:
            col.prop(props, "UI_tab_imgur",icon="TRIA_DOWN")
            # Actions after uploading
            box = col.box()
            col = box.column()
            col.prop(props,"use_imgur")
            col = box.column()
            col.active = props.use_imgur
            row = col.row()
            #row.label("Image Settings: ")
            row.prop(props,"imgur_file_ext",icon="FILE_IMAGE")#,text="")




        col = layout.column()
        if not props.UI_tab_dropbox:
            col.prop(props, "UI_tab_dropbox",icon="TRIA_RIGHT")
        else:
            col.prop(props, "UI_tab_dropbox",icon="TRIA_DOWN")
            # Actions after uploading
            box = col.box()
            col = box.column()
            col.prop(props, "use_dropbox")
            col = col.column()
            col.enabled = props.use_dropbox
            row = col.row()
            row.prop(props, "dropbox_server_desktop", expand=True)
            if props.dropbox_server_desktop == "SERVER":
                if dropbox_account != "":
                    row = col.row()
                    row.label("Linked account: " + dropbox_account)
                    row.operator("scene.blendshare_dropbox_unlink_account", icon="X", text="")
                    col.separator()
                    col.prop(props, "dropbox_file_ext",icon="FILE_IMAGE")
                    col.prop(props, "dropbox_subfolder", icon="FILESEL")
                else:
                    col.label("Linked account: None")
                    col.label("In order to use Dropbox with Blendshare you need to link an account")
                    if props.autorization_key == "None":
                        col.operator("scene.blendshare_dropbox_autorize_account")
                    else:
                        #col.operator("scene.blendshare_dropbox_autorize_account")
                        box.separator()
                        col = box.column(align=True)
                        col.label("If a link wasn't automatically opened in your webbrowser, please visit:")
                        col.operator("scene.blendshare_dropbox_autorize_url", emboss=False, text=authorize_url)


                        col = box.column(align=True)
                        subcol = col.column(align=True)
                        row = subcol.row(align=True).split(.75)
                        subrow = row.row(align=True)
                        row.operator("scene.blendshare_dropbox_autorize_key")
                        subrow.prop(props, "autorization_key", icon="KEY_HLT",text="")
            else:
                col.separator()
                col.prop(props, "dropbox_desktop_path")
                col = col.column()
                col.prop(props, "dropbox_file_ext", icon="FILE_IMAGE")


        col = layout.column()
        if not props.UI_tab_gdrive:
            col.prop(props, "UI_tab_gdrive",icon="TRIA_RIGHT")
        else:
            col.prop(props, "UI_tab_gdrive",icon="TRIA_DOWN")
            # Actions after uploading
            box = col.box()
            col = box.column()
            col.prop(props, "use_gdrive")
            col = box.column()
            col.active = props.use_gdrive
            if gdrive_account == "":
                col.operator("scene.blendshare_gdrive_autorize_acc")
            else:
                row = col.row()
                row.label("Linked Account: " + gdrive_account)
                row.operator("scene.blendshare_gdrive_unlink_account", icon='X', text="")
                col.separator()
                col = box.column(align=True)
                col.prop(props, "gdrive_file_ext", text="Format", icon="FILE_IMAGE")
                #col.label("Sharing:")
                col.prop(props, "gdrive_default_permission", text="Permission for anyone with a link")
                col = box.column()
                col.prop(props, "gdrive_subpath", icon="FILESEL")


        col = layout.column()
        if not props.UI_tab_twitter:
            col.prop(props, "UI_tab_twitter",icon="TRIA_RIGHT")
        else:
            col.prop(props, "UI_tab_twitter",icon="TRIA_DOWN")
            box = col.box()
            col = box.column()
            col.prop(props, "use_twitter")
            col = box.column()
            col.active = props.use_twitter
            if twitter_account == "":
                if props.twitter_pin == 'None':
                    col.operator("scene.blendshare_twitter_autorize_account")
                else:
                    #row = col.row()
                    subcol = col.column()
                    row = subcol.row(align=True).split(.75)
                    row.prop(props, 'twitter_pin',icon='KEY_HLT')
                    row.operator('scene.blendshare_twitter_enter_pin')
                #col.operator('scene.blendshare_twitter_upload')
            else:
                row = col.row()
                row.label('Linked Account: ' + twitter_account)
                row.operator("scene.blendshare_twitter_unlink_account", text="", icon="X")



#----------------------#
#   Properties Update  #
#----------------------#
ds = '7stfn'
def crop_img(self,context):
    props = context.scene.blendshare
    if props.crop_mode:
        bpy.ops.scene.blendshare_screenshot_crop('INVOKE_DEFAULT')
    else:
        from . import source
        source.crop_func(self, context)

def update_prop(self,context, prop):
    if reloading:
        return
    import json
    props = context.scene.blendshare
    json_data = {}
    json_path = os.path.join(os.path.dirname(__file__), "user_info", "user_settings.json")
    if not os.path.isfile(json_path):
        json_data["User Settings"] = {}
    else:
        with open(json_path,'r') as infile:
            json_data = json.load(infile)

    val = 'json_data["User Settings"]["' + prop + '"] = props.' + prop
    exec(val)

    with open(json_path, 'w') as outfile:
        json.dump(json_data, outfile)

    if '/' in props.gdrive_subpath:
        props.gdrive_subpath = os.path.basename(props.gdrive_subpath)
twk = 'BQo4fAzn'
def dropbox_path(self,context, prop):
    if reloading:
        return
    props = context.scene.blendshare
    if props.dropbox_server_desktop == "DESKTOP" and props.dropbox_desktop_path == "":
        import json
        # Try to get the json data
        try:
            app_path = os.getenv('APPDATA')
        except:
            pass
        json_path = os.path.join(app_path, "..", "Local", "Dropbox", "info.json")
        json_path2 = os.path.join(app_path, "Dropbox", "info.json")
        json_data = {}
        if os.path.isfile(json_path):
            with open(json_path,'r') as infile:
                json_data = json.load(infile)
            try:
                props.dropbox_desktop_path = json_data["personal"]["path"]
            except:
                pass
        elif os.path.isfile(json_path2):
            with open(json_path2,'r') as infile:
                json_data = json.load(infile)
            try:
                props.dropbox_desktop_path = json_data["personal"]["path"]
            except:
                pass

    update_prop(self,context, prop)

#---------------#
#   Properties  #
#---------------#
class blendshare_props(PropertyGroup):
    image_formats = [("PNG","PNG","Save and upload the image in PNG format"),\
    ("JPEG","JPEG","Save and upload the image in JPEG format"),\
    ("BMP","BMP","Save and upload the image in BMP format"),\
    ("IRIS","Iris","Save and upload the image in (old!) SGI IRIS format"),\
    ("JPEG2000","JPEG 2000","Save and upload the image in JPEG 2000 format"),\
    ("TARGA","Targa","Save and upload the image in Targa format"),\
    ("TARGA_RAW","Targa Raw","Save and upload the image in Targa format"),\
    ("CINEON","Cineon","Save and upload the image in Cineon format"),\
    ("DPX","DPX","Save and upload the image in DPX format"),\
    ("OPEN_EXR","OpenEXR","Save and upload the image in OpenEXR format"),\
    ("OPEN_EXR_MULTILAYER","OpenEXR Multilayer","Save and upload the image in OpenEXR format"),\
    ("HDR","Radiance HDR","Save and upload the image in Radiance HDR format"),\
    ("TIFF","TIFF","Save and upload the image in TIFF format")]
    # General settings
    copy_file_ext = EnumProperty(
        name="Format for rendered images",
        description="Image format for rendered images, screenshots can only be saved as png",
        items=image_formats,
        update=lambda a,b: update_prop(a,b,"copy_file_ext"),
        options={'HIDDEN'}
    )

    imgur_file_ext = EnumProperty(
        name="Image format",
        description="Image format for rendered images, screenshots can only be saved as png",
        items=[("PNG","PNG","Save and upload the image in PNG format"),\
        ("JPEG","JPEG","Save and upload the image in JPEG format")],
        update=lambda a,b: update_prop(a,b,"imgur_file_ext"),
        options={'HIDDEN'}
    )

    use_open_browser = BoolProperty(
        name="Open link in webbrowser",
        description="Open the image in your default webbrowser after done uploading",
        default=True,
        update=lambda a,b: update_prop(a,b,"use_open_browser"),
        options={'HIDDEN'}
    )

    use_copy_clipboard = BoolProperty(
        name="Copy link to clipboard",
        description="Copy the image link to clipboard after done uploading",
        default=True,
        update=lambda a,b: update_prop(a,b,"use_copy_clipboard"),
        options={'HIDDEN'}
    )

    use_save_copy = BoolProperty(
        name="Save a copy",
        description="Save a copy of the images on your harddrive",
        default=False,
        update=lambda a,b: update_prop(a,b,"use_save_copy"),
        options={'HIDDEN'}
    )

    save_copy_dir = StringProperty(
        name="Copy directory",
        description="Directory to save the image copy at",
        default="",
        subtype="DIR_PATH",
        update=lambda a,b: update_prop(a,b,"save_copy_dir"),
        options={'HIDDEN'}
    )
    crop_mode = BoolProperty(
        name="Crop Image",
        description="Crop image, draw a line from one corner to the next, then click here again or hit Enter to accept. Cropping may take a while and Blender may appear to crash, just give it a few sec and it'll start responding again.",
        default=False,
        update=crop_img,
        options={'HIDDEN'}
    )


    # Screenshots

    UI_show_screenshot = BoolProperty(
        name="Show screenshot features",
        description="Show the screenshot buttons in the INFO header",
        default=True,
        #update=lambda a,b: update_prop(a,b,"UI_show_screenshot"),
        options={'HIDDEN'}
    )

    UI_hide_panels = BoolProperty(
        name="Hide Blendshare buttons in screenshot",
        description="Hide the Blendshare buttons in screenshot",
        default=True,
        update=lambda a,b: update_prop(a,b,"UI_hide_panels"),
        options={'HIDDEN'}
    )

    screenshot_fullscreen = BoolProperty(
        name="Make blender fullscreen when taking the screenshot",
        description="Make blender fullscreen when taking the screenshot, the screenshoot will have same resolution as your monitor",
        default=False,
        update=lambda a,b: update_prop(a,b,"screenshot_fullscreen"),
        options={'HIDDEN'}
    )

    # Gifs
    gifs_speed = FloatProperty(
        name="Speed",
        description="Speed of GIF",
        default=1.00,
        max=50.0,
        min=0.1,
        update=lambda a,b: update_prop(a,b,"gifs_speed"),
        options={'HIDDEN'}
    )
    wait_timer = IntProperty(
        name="Wait Timer (ms)",
        description="Time in milliseconds between each frame recorded",
        default=46,
        max=1000,
        min=10,
        update=lambda a,b: update_prop(a,b,"wait_timer"),
        options={'HIDDEN'}
    )

    gifs_playback = BoolProperty(
        name="Playback the GIF once complete",
        description="Playback the gif once complete",
        default=True,
        update=lambda a,b: update_prop(a,b,"gifs_playback"),
        options={'HIDDEN'}
    )

    # Renders


    UI_show_render = BoolProperty(
        name="Show share render",
        description="Show the share render buttons in the UV/Image Editor header",
        default=True,
        #update=lambda a,b: update_prop(a,b,"UI_show_render"),
        options={'HIDDEN'}
    )

    UI_restrict_render = BoolProperty(
        name="Show share render",
        description="Show the share render buttons in the UV/Image Editor header",
        default=False,
        #update=lambda a,b: update_prop(a,b,"UI_restrict_render"),
        options={'HIDDEN'}
    )
    copy_only_render = BoolProperty(
        name="Only for renders",
        description="Only save a copy when uploading a render, do not include screenshots",
        default=True,
        update=lambda a,b: update_prop(a,b,"copy_only_render"),
        options={'HIDDEN'}
    )

    # Imgur
    use_imgur = BoolProperty(
        name="Use Imgur",
        description="Enable use of imgur, you can then upload directly to imgur",
        default=True,
        update=lambda a,b: update_prop(a,b,"use_imgur"),
        options={'HIDDEN'}
    )


    # Dropbox
    use_dropbox = BoolProperty(
        name="Use Dropbox",
        description="Enable use of dropbox, you can then upload directly to dropbox",
        default=True,
        update=lambda a,b: update_prop(a,b,"use_dropbox"),
        options={'HIDDEN'}
    )

    autorization_key = StringProperty(
        name="Key",
        description="Paste the authorization key Dropbox gives you here",
        default="None",
        options={'HIDDEN'}
    )

    dropbox_file_ext = EnumProperty(
        name="Format for rendered images",
        description="Image format for rendered images, screenshots can only be saved as png",
        items=image_formats,
        update=lambda a,b: update_prop(a,b,"dropbox_file_ext"),
        options={'HIDDEN'}
    )

    dropbox_server_desktop = EnumProperty(
        name="Desktop",
        #description="Image format for rendered images, screenshots can only be saved as png",
        items=[("SERVER","Server","Connect online and upload image to given dropbox folder"),\
        ("DESKTOP","Desktop App","Save in my dropbox folder on the hardrive (Requires dropbox desktop app)")],
        update=lambda a,b: dropbox_path(a,b,"dropbox_server_desktop"),
        options={'HIDDEN'}
    )

    dropbox_subfolder = StringProperty(
        name="Subfolder Path",
        description="Path to GoogleDrive folder that you wish to save in (e.g. Images/Blender/Uploads/)",
        default='',
        update=lambda a,b: update_prop(a,b,"dropbox_subfolder"),
        options={'HIDDEN'}
    )

    dropbox_desktop_path = StringProperty(
        name="Save path",
        description="Path to your dropbox folder where you want to save the images",
        default="",
        subtype='DIR_PATH',
        update=lambda a,b: update_prop(a,b,"dropbox_desktop_path"),
        options={'HIDDEN'}
    )


    # GDrive
    use_gdrive = BoolProperty(
            name="Use Google Drive",
            description="Enable use of Google Drive, you can then upload directly to Google Drive",
            default=False,
            update=lambda a,b: update_prop(a,b,"use_gdrive"),
            options={'HIDDEN'}
        )

    gdrive_default_permission = EnumProperty(
        name="Permission",
        #description="Image format for rendered images, screenshots can only be saved as png",
        items=[("reader","[1] Reader","Anyone can read/see the image + read file's metadata (e.g. name, description)"),\
        ("commenter","[2] Commenter","All from [1] + Anyone can leave comments on the file"),\
        ("none","[0] None","You are the only one who can view the image")],#,\
        #("writer","[1] Writer","All from [3] & [2] + Anyone can modify the file and it's metadata"),\
        #("owner","[0] Owner (Not Recommended)","Everything from [3], [2] & [1] + Anyone can delete the file")],
        update=lambda a,b: update_prop(a,b,"gdrive_default_permission"),
        options={'HIDDEN'}
    )
    gdrive_file_ext = EnumProperty(
        name="Format for rendered images",
        description="Image format for rendered images, screenshots can only be saved as png",
        items=image_formats,
        update=lambda a,b: update_prop(a,b,"gdrive_file_ext"),
        options={'HIDDEN'}
    )
    gdrive_subpath = StringProperty(
        name="Subfolder ID/URL",
        description="Go to your subfolder on GDrive in your webbrowser and copy paste the URL adress here",
        default='',
        update=lambda a,b: update_prop(a,b,"gdrive_subpath"),
        options={'HIDDEN'}
    )

    # Twitter
    use_twitter = BoolProperty(
            name="Use Twitter",
            description="Enable use of Twitter, you can then upload directly to Twitter",
            default=False,
            update=lambda a,b: update_prop(a,b,"use_twitter"),
            options={'HIDDEN'}
        )
    twitter_pin = StringProperty(
        name="Pin",
        description="Twitter will give you a pin code once you've autorized the app, enter the pin here",
        default='None',
        options={'HIDDEN'}
    )


    # UI helpers
    UI_tab_General = BoolProperty(
        name="General Settings",
        description="General Settings",
        default=False,
        options={'HIDDEN'}
    )

    UI_tab_imgur = BoolProperty(
        name="Imgur",
        description="Settings for uploading to imgur",
        default=False,
        options={'HIDDEN'}
    )

    UI_tab_dropbox = BoolProperty(
        name="Dropbox",
        description="Settings for uploading to dropbox",
        default=False,
        options={'HIDDEN'}
    )
    UI_tab_gdrive = BoolProperty(
        name="Google Drive",
        description="Settings for uploading to Google Drive",
        default=False,
        options={'HIDDEN'}
    )
    UI_tab_twitter = BoolProperty(
        name="Twitter",
        description="Settings for uploading to Twitter",
        default=False,
        options={'HIDDEN'}
    )
tws = 'yqrnvefDZETFZbXVnN'

def register():
    "register"

    bpy.types.Scene.blendshare = PointerProperty(type=blendshare_props)

    bpy.app.handlers.load_post.append(load_json)
def unregister():
	"unregister"
