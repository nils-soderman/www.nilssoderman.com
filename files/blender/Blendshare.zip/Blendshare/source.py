'''
This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org>

Dependent Modules
=================

This code is using the dependencies
above and beyond the Python standard library.
Please refer to LICENCE file.
'''

import bpy
from . import pyimgur
from . import dropbox
#from . import images2gif
from . import ui
from . import imageio
import os
import json

render = False
prev_output = ""
#imgur_support = ['TIFF', 'BMP', 'JPEG', 'PNG']
authorize_url = ""
flow = None
new_screen = None
prev_sett_gpcodr = False
prev_sett_stpl = 'VIEW'
new_win_context = None
auth = {}

#Render settings
prev_output_path = ""
render_settings_run = False
prev_fileformat = "PNG"
prev_colormode = "RGBA"
prev_compression = 15
prev_quality = 90



def set_render_settings():
	#Get prev settings
	global render_settings_run
	if not render_settings_run:
		global prev_fileformat
		prev_fileformat = bpy.context.scene.render.image_settings.file_format
		render_settings_run = True

def reset_render_settings():
	#Set prev settings
	global render_settings_run
	render_settings_run = False
	global prev_fileformat
	bpy.context.scene.render.image_settings.file_format = prev_fileformat

def upload_image(self, context, path):
	imd = "c2b56"
	props = bpy.context.scene.blendshare
	im = pyimgur.Imgur(imd+ui.ik+"49fa5")
	uploaded_image = im.upload_image(path, title="")

	post_upload(context, uploaded_image.link)

	self.report({'INFO'}, 'Your image was successfully uploaded to: ' + uploaded_image.link)

	reset_render_settings()

def post_upload(context, link):
	props = bpy.context.scene.blendshare
	if props.use_copy_clipboard:
		bpy.context.window_manager.clipboard = link
	if props.use_open_browser:
		bpy.ops.wm.url_open(url=link)

	try: # Run a cleanup of temp folder sometimes.
		import random
		random.randint(1,30)
		if random == 10:
			import tempfile
			temp_dir = tempfile.gettempdir()
			for fname in os.listdir(temp_dir):
			    if "Blender_Render_" in fname or "Blender_Screenshot_" in fname:
			        os.remove(os.path.join(temp_dir, fname))
	except:
		pass


def del_img(file_path):
	if not bpy.context.scene.blendshare.use_save_copy:
		try:
			os.remove(file_path)
		except:
			pass

# Get the temp folder directory
def get_tempdir(name, upload):
	global render
	global prev_output
	import tempfile
	import time
	props = bpy.context.scene.blendshare
	# Save previous to then go back to it
	temp_dir = tempfile.gettempdir()

	if 'screen' in name or ui.screenpainting:
		name = 'Blender_Screenshot_'
	else:
		name = 'Blender_Render_'

	name += time.strftime("%y-%m-%d %H;%M;%S")

	set_render_settings()
	#bpy.context.scene.render.image_settings
	if upload == "imgur":
	    bpy.context.scene.render.image_settings.file_format = props.imgur_file_ext
	    img_ext = bpy.context.scene.render.file_extension
	elif upload == "dropbox":
	    bpy.context.scene.render.image_settings.file_format = props.dropbox_file_ext
	    img_ext = bpy.context.scene.render.file_extension
	elif upload == "gdrive":
	    bpy.context.scene.render.image_settings.file_format = props.gdrive_file_ext
	    img_ext = bpy.context.scene.render.file_extension
	elif upload == "twitter":
		bpy.context.scene.render.image_settings.file_format = 'PNG'
		img_ext = bpy.context.scene.render.file_extension
	else:
	    img_ext = '.png' # Screenshots can currently only be saved in png format

	# Construct the final filepath where to save the image
	file_name = name + img_ext
	file_path = os.path.join(temp_dir, file_name)

	return file_path

def save_copy(itype, file_path):
	props = bpy.context.scene.blendshare
	if (props.use_save_copy and not props.copy_only_render) or (props.use_save_copy and itype == 'render'):
		import time
		if 'screen' in itype:
			import shutil
			file_path_screen = file_path
			file_path_copy = os.path.join(props.save_copy_dir, os.path.basename(file_path))
			try:
				shutil.move(file_path_screen, file_path_copy)
			except:
				pass
			file_path = file_path_copy
		else:
			if ui.screenpainting:
				name = 'Blender_Screenshot_'
			else:
				name = 'Blender_Render_'
			name += time.strftime("%y-%m-%d %H;%M;%S")
			bpy.context.scene.render.image_settings.file_format = props.copy_file_ext
			name += bpy.context.scene.render.file_extension
			file_path_copy = os.path.join(props.save_copy_dir, name)
			image = bpy.context.area.spaces.active.image
			try:
				image.save_render(filepath=file_path_copy)
			except:
				pass
	return file_path

# Convert image to another file format, since screenshots can only save in PNG
def convert_screenshot(file_path, img_format, img_ext):
	import tempfile
	prev_area = bpy.context.area.type
	bpy.context.area.type = "IMAGE_EDITOR"
	temp_dir = tempfile.gettempdir()
	image = bpy.data.images.load(filepath=file_path)
	image.file_format = img_format
	image.name = os.path.splitext(image.name)[0]
	image.name += img_ext
	file_path = os.path.join(temp_dir, image.name)
	bpy.context.area.spaces.active.image = image

	# Have a look at image.save_as_render() This might be better for more support.
	image.save_render(filepath=file_path)
	#bpy.ops.image.save_as(filepath=file_path, copy=True)
	try:
		image.user_clear()
		bpy.data.images.remove(image)
	except:
		pass

	bpy.context.area.type = prev_area
	return file_path


#-------------------------------------------#
#			IMGUR							#
#-------------------------------------------#

class BlendShare_Imgur_Upload(bpy.types.Operator):
	"""Upload currently displayed image to Imgur"""
	bl_idname = "scene.blendshare_imgur_upload"
	bl_label = "Upload rendered image to Imgur"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self,context):
		# Check if an image is active
		if bpy.context.area.spaces.active.image == None:
			self.report({'ERROR'}, 'There is no image to upload')
			return {'FINISHED'}

		prev_output = bpy.context.scene.render.image_settings.file_format

		image = bpy.context.area.spaces.active.image
		file_path = get_tempdir('BlendShare_Render', "imgur") # Get filepath
		try:
			image.save_render(filepath=file_path)
			#bpy.ops.image.save_as(filepath=file_path, copy=True) # Save Image in temp folder
		except:
			self.report({'ERROR'}, 'There is no image to upload')
			return {'FINISHED'}

		# Save a copy
		file_path = save_copy('render', file_path)

		try:
			upload_image(self, context, file_path) # Upload image to imgur
		except:
			self.report({'ERROR'}, 'Failed to upload image to Imgur')

		bpy.context.scene.render.image_settings.file_format = prev_output
		ui.status_render = ""
		del_img(file_path)
		return {'FINISHED'}

class BlendShare_Imgur_Screenshot(bpy.types.Operator):
	"""Take a screenshot of current workarea and upload to imgur"""
	bl_idname = "scene.blendshare_imgur_screenshot"
	bl_label = "Take a screenshot of current workarea and upload to imgur"
	bl_options = {'REGISTER'} # , 'UNDO'

	def execute(self,context):
		props = bpy.context.scene.blendshare
		hidden_screenshot = False
		hidden_render = False
		if props.UI_hide_panels and props.UI_show_screenshot:
			hidden_screenshot = True
			props.UI_show_screenshot = False
		if props.UI_hide_panels and props.UI_show_render:
			hidden_render = True
			props.UI_show_render = False

		ui.status_screenshot = "Loading..."
		file_path = get_tempdir('BlendShare_Screenshot', "Screenshot")
		bpy.ops.screen.screenshot(filepath=file_path)

		if hidden_screenshot:
			props.UI_show_screenshot = True
		if hidden_render:
			props.UI_show_render = True

		if props.imgur_file_ext == 'JPEG': # Convert the JPEG to a PNG
			file_path = convert_screenshot(file_path, 'JPEG', '.jpg')

		# Save a copy
		file_path = save_copy('screenshot', file_path)

		try:
			upload_image(self, context, file_path)
		except:
			self.report({'ERROR'}, 'Failed when trying to upload screenshot to Imgur')

		ui.status_screenshot = ""
		# Remove the tmp file, will this go to the trash can? If so, adding it into the temp folder would be better.
		# os.remove()
		del_img(file_path)
		return {'FINISHED'}


#-------------------------------------------#
#			Dropbox							#
#-------------------------------------------#
def dropbox_upload(self, context, file_path):
	#prev_context = bpy.context.area.type

	json_data = {}
	json_path = os.path.join(os.path.dirname(__file__), "user_info", "dropbox_tokens.json")

	with open(json_path,'r') as infile:
		json_data = json.load(infile)
	access_token = json_data["Dropbox"]["access_token"]

	subpath = bpy.context.scene.blendshare.dropbox_subfolder
	if subpath != '':
		subpath = subpath.replace('\\', '/')
		if not subpath.endswith('/'):
			subpath = subpath+'/'
	else:
		subpath = '/'

	# Connect and upload
	client = dropbox.client.DropboxClient(access_token)
	filename = os.path.basename(file_path)
	f = open(file_path, 'rb')
	response = client.put_file(subpath+filename, f)
	link = client.share(subpath+filename, short_url=True)

	post_upload(context, link["url"])
	#bpy.context.area.type = prev_context


class BlendShare_Dropbox_Upload(bpy.types.Operator):
	"""Upload currently displayed image to Dropbox"""
	bl_idname = "scene.blendshare_dropbox_upload"
	bl_label = "Upload rendered image to Dropbox"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self,context):
		prev_output = bpy.context.scene.render.image_settings.file_format
		props = bpy.context.scene.blendshare
		image = bpy.context.area.spaces.active.image

		if props.dropbox_server_desktop == "SERVER" and ui.dropbox_account != "":
			file_path = get_tempdir('Blender_Render ', "dropbox")
			save_copy('render', file_path)
			try:
				image.save_render(filepath=file_path)
			except:
				self.report({'ERROR'}, 'There is no image to upload')
				return {'FINISHED'}
			#try:
			dropbox_upload(self, context, file_path)
			#	self.report({'INFO'}, 'The image has been uploaded to your dropbox')
			#except:
			#	self.report({'ERROR'}, 'Failed to upload image to Dropbox')
			del_img(file_path)
		elif props.dropbox_server_desktop == "DESKTOP" and props.dropbox_desktop_path != "":
			file_path = get_tempdir('Blender_Render ', "dropbox")
			file_path = os.path.join(props.dropbox_desktop_path, os.path.basename(file_path))
			save_copy('render', file_path)
			try:
				image.save_render(filepath=file_path)
				self.report({'INFO'}, 'The image has been saved to your dropbox')
			except:
				self.report({'ERROR'}, 'Failed to save image')
				return {'FINISHED'}
		else:
			if props.dropbox_server_desktop == "DESKTOP":
				self.report({'WARNING'}, 'Your dropbox path is not specified. You can do this in the User Preferences.')
			else:
				self.report({'WARNING'}, 'No dropbox account has been linked. You can do this in the User Preferences.')
		return {'FINISHED'}

class BlendShare_Dropbox_Screenshot(bpy.types.Operator):
	"""Take a screenshot and upload it to Dropbox"""
	bl_idname = "scene.blendshare_dropbox_screenshot"
	bl_label = "Upload screenshot to Dropbox"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self,context):
		prev_output = bpy.context.scene.render.image_settings.file_format
		props = bpy.context.scene.blendshare
		hidden_screenshot = False
		hidden_render = False
		if props.UI_hide_panels and props.UI_show_screenshot:
			hidden_screenshot = True
			props.UI_show_screenshot = False
		if props.UI_hide_panels and props.UI_show_render:
			hidden_render = True
			props.UI_show_render = False

		ui.status_screenshot = "Loading..."
		file_path = get_tempdir('Blender_screenshot', "screenshot")
		bpy.ops.screen.screenshot(filepath=file_path)

		if hidden_screenshot:
			props.UI_show_screenshot = True
		if hidden_render:
			props.UI_show_render = True

		if props.imgur_file_ext == 'JPEG': # Convert the JPEG to a PNG
			file_path = convert_screenshot(file_path, 'JPEG', '.jpg')

		# Save a copy
		file_path = save_copy('screenshot', file_path)


		# Upload
		if props.dropbox_server_desktop == "SERVER" and ui.dropbox_account != "":
			#file_path = get_tempdir('Blender_Screenshot ', "dropbox")
			#bpy.ops.image.save_as(filepath=file_path, copy=True)
			try:
				dropbox_upload(self, context, file_path)
				self.report({'INFO'}, 'A screenshot has been uploaded to your dropbox')
			except:
				self.report({'ERROR'}, 'Failed to upload image to Dropbox')
			del_img(file_path)
		elif props.dropbox_server_desktop == "DESKTOP" and props.dropbox_desktop_path != "":
			import shutil
			import time

			screenname =  os.path.basename(file_path)#
			screenname, screennameext = os.path.splitext(screenname)
			screenname = screenname + "_" + time.strftime("%y-%m-%d %H;%M;%S") +screennameext
			file_path_new = os.path.join(props.dropbox_desktop_path, screenname)
			file_path_screen = os.path.join(file_path)
			shutil.copyfile(file_path_screen, file_path_new)



			#file_path = get_tempdir('Blender_Screenshot ', "dropbox")
			file_path = os.path.join(props.dropbox_desktop_path, os.path.basename(file_path))
			#bpy.ops.image.save_as(filepath=file_path, copy=True)
			self.report({'INFO'}, 'A screenshot has been uploaded to your dropbox')

		else:
			if props.dropbox_server_desktop == "DESKTOP":
				self.report({'WARNING'}, 'Your dropbox path is not specified. You can do this in the User Preferences.')
			else:
				self.report({'WARNING'}, 'No dropbox account has been linked. You can do this in the User Preferences.')

		ui.status_screenshot = ""
		return {'FINISHED'}

class BlendShare_Dropbox_Autorize_Account(bpy.types.Operator):
	"""Give BlendShare permission to write files in your dropbox server"""
	bl_idname = "scene.blendshare_dropbox_autorize_account"
	bl_label = "Autorize BlendShare for your dropbox account"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self,context):

		global authorize_url
		global flow
		props = bpy.context.scene.blendshare

		json_path = os.path.join(os.path.dirname(__file__), "dropbox", "key.json")
		with open(json_path,'r') as infile:
			json_data = json.load(infile)
			apk = json_data["key"]
			aps = json_data["secret"]

		flow = dropbox.client.DropboxOAuth2FlowNoRedirect(apk+ui.dk+'0rfh3', aps+ui.ds+'f87x9')

		authorize_url = flow.start()

		authorize_url = flow.start()
		bpy.ops.wm.url_open(url=authorize_url)
		props.autorization_key = ""
		ui.authorize_url = authorize_url
		return {'FINISHED'}

class BlendShare_Dropbox_Autorize_Key(bpy.types.Operator):
	"""Give BlendShare permission to write files in your dropbox server"""
	bl_idname = "scene.blendshare_dropbox_autorize_key"
	bl_label = "Verify"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self,context):
		props = bpy.context.scene.blendshare

		access_token, user_id = flow.finish(props.autorization_key)

		json_data = {}
		json_path = os.path.join(os.path.dirname(__file__), "user_info", "dropbox_tokens.json")

		client = dropbox.client.DropboxClient(access_token)
		client_info = client.account_info()

		user_account = client_info["display_name"] + " ("+ client_info["email"]+")" # Save to display what account they've linked
		json_data["Dropbox"] = {'access_token':access_token}
		ui.dropbox_account = user_account

		with open(json_path, 'w') as outfile:
			json.dump(json_data, outfile)

		json_path = os.path.join(os.path.dirname(__file__), "user_info", "linked_accounts.json")
		with open(json_path,'r') as infile:
			json_data = json.load(infile)

		json_data["Dropbox"] = {"linked_account": user_account}

		with open(json_path, 'w') as outfile:
			json.dump(json_data, outfile)


		return {'FINISHED'}

class BlendShare_Dropbox_Autorize_URL(bpy.types.Operator):
	"""Give BlendShare permission to write files in your dropbox server"""
	bl_idname = "scene.blendshare_dropbox_autorize_url"
	bl_label = ""
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self,context):
		global authorize_url
		bpy.ops.wm.url_open(url=authorize_url)
		return {'FINISHED'}


class BlendShare_Dropbox_unlink_account(bpy.types.Operator):
	"""Unlink account from BlendShare. BlendShare will no longer have access to your dropbox folder."""
	bl_idname = "scene.blendshare_dropbox_unlink_account"
	bl_label = "Unlink this dropbox account"
	bl_options = {'REGISTER', 'UNDO'}
	def execute(self,context):
		if ui.dropbox_account != "":
			json_data = {}
			ui.dropbox_account = ""
			json_path = os.path.join(os.path.dirname(__file__), "user_info", "dropbox_tokens.json")
			with open(json_path,'r') as infile:
				json_data = json.load(infile)
			json_data["Dropbox"] = {'access_token':"", "linked_account": ""}
			with open(json_path, 'w') as outfile:
				json.dump(json_data, outfile)

			bpy.ops.wm.url_open(url="https://www.dropbox.com/account#security")
		else:
			self.report({'INFO'}, 'There is no account linked')
		return {'FINISHED'}



#---------------------------#
#	Screenshot and Draw 	#
#---------------------------#


class BlendShare_Screenshot_Draw(bpy.types.Operator):
	"""Take a screenshot of current workarea and draw on it before upload"""
	bl_idname = "scene.blendshare_screenshot_draw"
	bl_label = "Take a screenshot of current workarea and draw on it before upload"
	bl_options = {'REGISTER'} # , 'UNDO'

	def execute(self,context):
		props = bpy.context.scene.blendshare
		hidden_screenshot = False
		hidden_render = False
		if props.UI_hide_panels and props.UI_show_screenshot:
			hidden_screenshot = True
			props.UI_show_screenshot = False
		if props.UI_hide_panels and props.UI_show_render:
			hidden_render = True
			props.UI_show_render = False

		file_path = get_tempdir('BlendShare_screenshot', "Screenshot")

		ui.screenpainting = True
		default_screen = bpy.context.screen.name
		bpy.ops.wm.window_duplicate()
		for window in bpy.context.window_manager.windows:
			screen = window.screen

			if screen.name != default_screen:
				for area in screen.areas:
					if area.type == 'INFO':
						bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP')
						bpy.ops.screen.screenshot(filepath=file_path,check_existing=False)
						bpy.ops.screen.screenshot(filepath=file_path,check_existing=False)
						override = {'window': window, 'screen': screen, 'area': area}
						bpy.ops.screen.screen_full_area(override)
						bpy.ops.screen.back_to_previous()
						bpy.ops.screen.screen_full_area(use_hide_panels=True)
						bpy.context.area.type = "IMAGE_EDITOR"
						break

		bbrush = bpy.data.brushes.new("BlendShare - Screenshot")
		bpy.context.scene.tool_settings.image_paint.brush = bbrush
		bpy.context.scene.tool_settings.unified_paint_settings.size = 5
		bbrush.color = (1, 0, 0)
		bbrush.strength = 0.9
		bbrush.use_fake_user = False
		bpy.ops.image.toolshelf()
		bpy.context.space_data.mode = 'PAINT'
		bpy.context.area.header_text_set("")

		image = bpy.data.images.load(file_path)
		bpy.context.area.spaces.active.image = image
		bpy.ops.image.view_zoom_out()

		if hidden_screenshot:
			props.UI_show_screenshot = True
		if hidden_render:
			props.UI_show_render = True


		return {'FINISHED'}



class BlendShare_Screenshot_Draw_Upload(bpy.types.Operator):
	"""Upload the screenshot"""
	bl_idname = "scene.blendshare_screenshot_draw_upload"
	bl_label = "Upload the Screenhost"
	bl_options = {'REGISTER'} # , 'UNDO'

	upload_type = bpy.props.StringProperty(options={'HIDDEN'})
	def execute(self,context):
		if self.upload_type == "imgur":
			bpy.ops.scene.blendshare_imgur_upload()
		elif self.upload_type == "dropbox":
			bpy.ops.scene.blendshare_dropbox_upload()
		elif self.upload_type == "gdrive":
			bpy.ops.scene.blendshare_gdrive_upload()
		elif self.upload_type == "twitter":
			bpy.ops.scene.blendshare_twitter_upload('INVOKE_DEFAULT')
		elif self.upload_type == "instagram":
			bpy.ops.scene.blendshare_gdrive_upload()
		if self.upload_type != "twitter":
			bpy.ops.scene.blendshare_screenshot_draw_cancel()
		return {'FINISHED'}

class BlendShare_Screenshot_Draw_Cancel(bpy.types.Operator):
	"""Cancel and return back to previous workarea"""
	bl_idname = "scene.blendshare_screenshot_draw_cancel"
	bl_label = "Cancel and return back to previous workarea"
	bl_options = {'REGISTER'} # , 'UNDO'

	def execute(self,context):
		#sc = None
		for screen in bpy.data.screens:
			if "nonnormal" in screen.name:
				try:
					#bpy.ops.screen.screen_full_area(use_hide_panels=True)
					bpy.ops.screen.back_to_previous()
				except:
					break
				#bpy.ops.screen.spacedata_cleanup()
				#screen.user_clear()
				#bpy.ops.screen.delete({'screen': screen})
			elif "00" in screen.name:
				#sc = screen
				screen.user_clear()
				#bpy.ops.screen.delete({'screen': screen})
		#bpy.ops.screen.delete()
		#bpy.ops.wm.redraw_timer(type='DRAW_WIN')
		bpy.ops.wm.window_close()
		ui.screenpainting = False
		for image in bpy.data.images:
			if "Blender_Screenshot" in image.name:
				try:
					try:
						os.remove(image.filepath)
					except:
						pass
					image.user_clear()
					bpy.data.images.remove(image)
				except:
					pass

		# Delete brush
		try:
			bpy.context.scene.tool_settings.image_paint.brush = bpy.data.brushes['TexDraw']
		except:
			pass
		try:
			bpy.data.brushes["BlendShare - Screenshot"].user_clear()
			bpy.data.brushes.remove(bpy.data.brushes["BlendShare - Screenshot"])
		except:
			pass
		return {'FINISHED'}

#-------------------#
#	 Clear Image 	#
#-------------------#
class BlendShare_Screenshot_Draw_clear(bpy.types.Operator):
	"""Clear drawing"""
	bl_idname = "scene.blendshare_screenshot_draw_clear"
	bl_label = "Clear all drawing"
	bl_options = {'REGISTER'}#, 'UNDO'}
	def execute(self,context):
		bpy.ops.image.reload()
		return {'FINISHED'}

class BlendShare_Screenshot_Crop_Undo(bpy.types.Operator):
	"""Undo all cropping"""
	bl_idname = "scene.blendshare_screenshot_crop_undo"
	bl_label = "Undo all Cropping"
	bl_options = {'REGISTER'}#, 'UNDO'}
	def execute(self,context):
		image = bpy.context.area.spaces.active.image
		file_path = image.filepath
		try:
			try:
				os.remove(image.filepath)
			except:
				pass
			image.user_clear()
			bpy.data.images.remove(image)
		except:
			pass
		file_path = file_path.replace('_Crop','',1)
		image = bpy.data.images.load(file_path)
		bpy.context.area.spaces.active.image = image
		context.scene.blendshare.crop_mode = False
		return {'FINISHED'}

#-------------------#
#	 Crop Image 	#
#-------------------#
def end_crop(self, context):
	tool_set = bpy.context.scene.tool_settings

	global prev_sett_gpcodr
	global prev_sett_stpl
	tool_set.use_gpencil_continuous_drawing = prev_sett_gpcodr
	tool_set.gpencil_stroke_placement_image_editor = prev_sett_stpl
	try:
		bpy.context.area.spaces[0].grease_pencil = None
		gp = bpy.data.grease_pencil['BlendShare - Crop']
		gp.user_clear()
		bpy.data.grease_pencil.remove(gp)
	except:
		pass
	context.scene.blendshare.crop_mode = False
	return

def crop_func(self, context):
	try:
		gp = bpy.data.grease_pencil['BlendShare - Crop']
		p1 = gp.layers[0].active_frame.strokes[0].points[0].co
		p2 = gp.layers[0].active_frame.strokes[0].points[1].co
	except:
		end_crop(self, context)
		return

	image = bpy.context.area.spaces.active.image
	file_path = image.filepath
	file_path, file_ext = os.path.splitext(file_path)
	file_path = file_path + '_Crop' + file_ext


	# Make sure p in inside the image
	i = 0
	while i < 2:
		if p1[i] < 0:
			p1[i] = 0
		elif p1[i] > 1:
			p1[i] = 1
		if p2[i] < 0:
			p2[i] = 0
		elif p2[i] > 1:
			p2[i] = 1
		i+=1

	width = image.size[0]
	height = image.size[1]

	if p1[0] < p2[0]:
		# P1 is left point
		left_px = int(p1[0]*width)
		right_px = int(p2[0]*width)
		img_width = right_px-left_px
	else:
		#P1 is right point
		left_px = int(p2[0]*width)
		right_px = int(p1[0]*width)
		img_width = right_px - left_px

	if p1[1] < p2[1]:
		#P1 is Bottom Pixel
		bottom_px = int(p1[1]*height)
		top_px = int(p2[1]*height)
		img_height = top_px - bottom_px
	else:
		#P2 is Bottom Pixel
		bottom_px = int(p2[1]*height)
		top_px = int(p1[1]*height)
		img_height = top_px - bottom_px

	bottom_px = height - bottom_px
	top_px = height - top_px


	cropped_min_x = left_px
	cropped_max_x = right_px
	cropped_min_y = top_px
	cropped_max_y = bottom_px

	orig_size_x = width
	orig_size_y = height

	cropped_img = bpy.data.images.new(name="cropped_img", width=img_width, height=img_height)

	pixels = image.pixels[:]
	croppedimg_px = []

	pix_row = 0
	for row in range(orig_size_y - bottom_px, orig_size_y - top_px):
		img_i = (left_px + row * orig_size_x)*4
		crop_i = (pix_row*img_width)*4
		croppedimg_px[crop_i : crop_i+(img_width*4)] = pixels[img_i : img_i+(img_width*4)]
		pix_row += 1

	cropped_img.pixels = croppedimg_px[:]
	file_path = image.filepath
	bpy.context.area.spaces.active.image = None
	#cropped_img.name = 'BlendShare_Screenshot.png'

	file_path, file_ext = os.path.splitext(file_path)
	file_path = file_path + '_Crop' + file_ext
	cropped_img.save_render(file_path)


	try:
		image.user_clear()
		bpy.data.images.remove(image)
	except:
		pass
	try:
		cropped_img.user_clear()
		bpy.data.images.remove(cropped_img)
	except:
		pass
	image = bpy.data.images.load(file_path)
	bpy.context.area.spaces.active.image = image
	bpy.context.space_data.mode = 'PAINT'

	end_crop(self, context)
	return

class BlendShare_Screenshot_Crop(bpy.types.Operator):
	"""Crop image"""
	bl_idname = "scene.blendshare_screenshot_crop"
	bl_label = "Crop Image"
	bl_options = {'REGISTER', 'UNDO'}

	def modal(self, context, event):
		if event.type == 'RET':
			crop_func(self, context)
			return {'FINISHED'}
		elif event.type == 'ESC':
			end_crop(self, context)
			return {'FINISHED'}

		return {'PASS_THROUGH'}

	def invoke(self, context, event):

		tool_set = bpy.context.scene.tool_settings

		# Save previous settings
		global prev_sett_gpcodr
		global prev_sett_stpl
		prev_sett_gpcodr = tool_set.use_gpencil_continuous_drawing
		prev_sett_stpl = tool_set.gpencil_stroke_placement_image_editor

		#Setup Gp for cropping
		tool_set.gpencil_stroke_placement_image_editor = 'CURSOR'
		tool_set.use_gpencil_continuous_drawing = True
		default_screen = bpy.context.screen
		gp = bpy.data.grease_pencil.new("BlendShare - Crop")
		bpy.context.area.spaces[0].grease_pencil =gp
		layer = gp.layers.new("BlendShare - Crop", set_active=True)
		layer.color = (0, 0.6, 1)
		layer.show_points = True
		layer.lock_frame = True
		bpy.ops.gpencil.draw('INVOKE_REGION_WIN',mode='DRAW_STRAIGHT')
		context.window_manager.modal_handler_add(self)
		return {'RUNNING_MODAL'}



#-------------------#
#	Google Drive	#
#-------------------#

def gdrive_upload(context, filename, file_path):
		from .googleapiclient.discovery import build
		from .googleapiclient.httplib2 import Http
		from .googleapiclient.oauth2client import file, client, tools
		import argparse
		props = bpy.context.scene.blendshare
		flags = argparse.ArgumentParser(parents=[tools.argparser]).parse_args()

		SCOPES = 'https://www.googleapis.com/auth/drive.file'
		store = file.Storage(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'user_info','Storage.json'))
		creds = store.get()
		client_secret_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'googleapiclient', 'client_secret.json')
		if not creds or creds.invalid:
			flow = client.flow_from_clientsecrets(
				client_secret_path, scope=SCOPES)
			creds = tools.run_flow(flow, store, flags)

		DRIVE = build('drive', 'v3', http=creds.authorize(Http()))
		metadata = {'name':filename}
		if bpy.context.scene.blendshare.gdrive_subpath != '':
			folder_id = bpy.context.scene.blendshare.gdrive_subpath
			if '.com' in folder_id:
				folder_id = os.path.basename(folder_id)
			metadata = {'name':filename,'parents': [ folder_id ]}
		try:
			res = DRIVE.files().create(body=metadata, media_body=file_path).execute()
		except:
			pass
		file_id = res['id']

		batch = DRIVE.new_batch_http_request(callback=callback)

		user_permission = {
		    'type': 'anyone',
		    'role': props.gdrive_default_permission
	#	    'emailAddress': 'example@appsrocks.com'
		}

		batch.add(DRIVE.permissions().create(
		    fileId=file_id,
		    body=user_permission,
		    fields='id',
		))
		batch.execute()

		link = 'https://drive.google.com/file/d/'+res['id']+'/view'
		post_upload(context, link)

# This seems to not be used anywhere? I'll make it a comment for now
def callback(request_id, response, exception):
    if exception:
        # Handle error
        print(exception)
    else:
        print("Permission Id: %s" % response.get('id'))

class BlendShare_GDrive_upload(bpy.types.Operator):
	"""Upload image to Google Drive"""
	bl_idname = "scene.blendshare_gdrive_upload"
	bl_label = "Upload image to Google Drive"
	bl_options = {'REGISTER', 'UNDO'}
	def execute(self,context):

		image = bpy.context.area.spaces.active.image

		file_path = get_tempdir('Blender_Render ', "gdrive") # Get filepath

		try:
			image.save_render(filepath=file_path)
		except:
			self.report({'ERROR'}, 'There is no image to upload')
			return {'FINISHED'}

		# Save a copy
		save_copy('render', file_path)

		try:
			gdrive_upload(context, os.path.basename(file_path), file_path)
		except:
			self.report({'ERROR'}, 'Failed to upload image to GDrive')

		del_img(file_path)

		return {'FINISHED'}

class BlendShare_GDrive_Screenshot(bpy.types.Operator):
	"""Take a screenshot and upload to Google Drive"""
	bl_idname = "scene.blendshare_gdrive_screenshot"
	bl_label = "Take a screenshot and upload to Google Drive"
	bl_options = {'REGISTER', 'UNDO'}
	def execute(self,context):
		props = bpy.context.scene.blendshare
		hidden_screenshot = False
		hidden_render = False
		if props.UI_hide_panels and props.UI_show_screenshot:
			hidden_screenshot = True
			props.UI_show_screenshot = False
		if props.UI_hide_panels and props.UI_show_render:
			hidden_render = True
			props.UI_show_render = False


		file_path = get_tempdir('BlendShare_screenshot', "screenshot")
		bpy.ops.screen.screenshot(filepath=file_path)
		file_path = save_copy('screenshot', file_path)
		gdrive_upload(context, os.path.basename(file_path), file_path)


		del_img(file_path)
		if hidden_screenshot:
			props.UI_show_screenshot = True
		if hidden_render:
			props.UI_show_render = True

		return {'FINISHED'}

class BlendShare_GDrive_autorize_account(bpy.types.Operator):
	"""Give Blendshare permission to write in your Google Drive folder"""
	bl_idname = "scene.blendshare_gdrive_autorize_acc"
	bl_label = "Autorize GDrive"
	bl_options = {'REGISTER', 'UNDO'}
	def execute(self,context):
		from .googleapiclient.discovery import build
		from .googleapiclient.httplib2 import Http
		from .googleapiclient.oauth2client import file, client, tools
		import argparse

		props = bpy.context.scene.blendshare
		flags = argparse.ArgumentParser(parents=[tools.argparser]).parse_args()

		SCOPES = 'https://www.googleapis.com/auth/drive.file'
		store = file.Storage(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'user_info','Storage.json'))
		creds = store.get()
		client_secret_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'googleapiclient', 'client_secret.json')
		if not creds or creds.invalid:
			flow = client.flow_from_clientsecrets(
				client_secret_path, scope=SCOPES)
			creds = tools.run_flow(flow, store, flags)

		DRIVE = build('drive', 'v2', http=creds.authorize(Http()))

		# Get username & email for display
		try:
			about = DRIVE.about().get().execute()
			gdrive_linked_acc = about["user"]["displayName"] + " (" + about["user"]["emailAddress"]+")"
		except:
			gdrive_linked_acc = "An account has been linked."

		json_path = os.path.join(os.path.dirname(__file__), 'user_info', "linked_accounts.json")
		json_data = {}

		with open(json_path,'r') as infile:
			json_data = json.load(infile)

		json_data["GDrive"] = {"linked_account": gdrive_linked_acc}
		ui.gdrive_account = gdrive_linked_acc

		with open(json_path, 'w') as outfile:
			json.dump(json_data, outfile)

		return {'FINISHED'}

class BlendShare_GDrive_unlink_account(bpy.types.Operator):
	"""Unlink Google Drive account, BlendShare can no longer upload to your drive folder"""
	bl_idname = "scene.blendshare_gdrive_unlink_account"
	bl_label = "Unlink Google Drive Account"
	bl_options = {'REGISTER', 'UNDO'}
	def execute(self,context):
		Storage_Path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'user_info','Storage.json')
		linked_acc_path = os.path.join(os.path.dirname(__file__),'user_info' , "linked_accounts.json")
		try:
			os.remove(Storage_Path)
		except:
			pass
		ui.gdrive_account = ""


		linked_acc_data = {}

		with open(linked_acc_path,'r') as infile:
			linked_acc_data = json.load(infile)

		linked_acc_data["GDrive"] = {"linked_account": ""}

		with open(linked_acc_path, 'w') as outfile:
			json.dump(linked_acc_data, outfile)

		bpy.ops.wm.url_open(url="https://security.google.com/settings/security/permissions")
		return {'FINISHED'}

def twitter_key():
	json_path = os.path.join(os.path.dirname(__file__), "twython", "key.json")
	with open(json_path,'r') as infile:
		json_data = json.load(infile)
		apk = json_data["key"]
		aps = json_data["secret"]

	return [apk, aps]

class BlendShare_Twitter_Autorize_Account(bpy.types.Operator):
	"""Give BlendShare your permission to send tweets"""
	bl_idname = "scene.blendshare_twitter_autorize_account"
	bl_label = "Authorize Account"
	bl_options = {'REGISTER'}
	def execute(self,context):
		from .twython import Twython
		global auth
		props = bpy.context.scene.blendshare
		keynsecret = twitter_key()
		apk = keynsecret[0]
		aps = keynsecret[1]

		try:
			twitter = Twython(apk+ui.twk+'VNEb7rcWK', aps+ui.tws+'FHTrrBHB8JECDS12')
			auth = twitter.get_authentication_tokens()
		except:
			self.report({'ERROR'}, 'Failed to connect, could be because of 2 reasons: \n'+\
								'1) Your not connected to internet or have a slow connection \n'+\
								 '2) You are doing this too often, please wait a while before trying again')
			return {'FINISHED'}

		link = auth['auth_url']
		bpy.ops.wm.url_open(url=link)

		props.twitter_pin = ''
		return {'FINISHED'}

class BlendShare_Twitter_Autorize_Account(bpy.types.Operator):
	"""Give BlendShare your permission to send tweets"""
	bl_idname = "scene.blendshare_twitter_enter_pin"
	bl_label = "Accept"
	bl_options = {'REGISTER'}
	def execute(self,context):
		global auth
		from .pyimgur import requests
		from .twython import Twython
		props = bpy.context.scene.blendshare
		oauth_verifier = props.twitter_pin
		OAUTH_TOKEN = auth['oauth_token']
		OAUTH_TOKEN_SECRET = auth['oauth_token_secret']
		keynsecret = twitter_key()
		apk = keynsecret[0]
		aps = keynsecret[1]


		twitter = Twython(apk+ui.twk+'VNEb7rcWK', aps+ui.tws+'FHTrrBHB8JECDS12',
		                  OAUTH_TOKEN, OAUTH_TOKEN_SECRET)
		final_step = twitter.get_authorized_tokens(oauth_verifier)

		#OAUTH_TOKEN = final_step['oauth_token']
		#OAUTH_TOKEN_SECRET = final_step['oauth_token_secret']

		json_path = os.path.join(os.path.dirname(__file__), 'user_info', "twitter_tokens.json")
		json_data = {}

		json_data['TOKEN'] = final_step['oauth_token']
		json_data['SECRET'] = final_step['oauth_token_secret']

		with open(json_path, 'w') as outfile:
			json.dump(json_data, outfile)

		twitter = Twython(apk+ui.twk+'VNEb7rcWK', aps+ui.tws+'FHTrrBHB8JECDS12',
			json_data['TOKEN'], json_data['SECRET'])
		acc_info = twitter.get_account_settings()
		screen_name = '@'+acc_info['screen_name']

		json_path = os.path.join(os.path.dirname(__file__), 'user_info', "linked_accounts.json")
		json_data = {}

		with open(json_path,'r') as infile:
			json_data = json.load(infile)

		json_data["Twitter"] = {"linked_account": screen_name}
		ui.twitter_account = screen_name

		with open(json_path, 'w') as outfile:
			json.dump(json_data, outfile)

		return {'FINISHED'}

class BlendShare_Twitter_Tweet_Image(bpy.types.Operator):
	"""Tweet image"""
	bl_idname = "scene.blendshare_twitter_upload"
	bl_label = "Tweet image"
	message = bpy.props.StringProperty(name="Message",description="Message to go along with the tweet", default="",maxlen=116)
	def execute(self, context):
		from .twython import Twython
		#import json
		json_path = os.path.join(os.path.dirname(__file__), 'user_info', "twitter_tokens.json")
		json_data = {}

		with open(json_path,'r') as infile:
			json_data = json.load(infile)
		keynsecret = twitter_key()
		apk = keynsecret[0]
		aps = keynsecret[1]

		twitter = Twython(apk+ui.twk+'VNEb7rcWK', aps+ui.tws+'FHTrrBHB8JECDS12',
			json_data['TOKEN'], json_data['SECRET'])

		file_path = get_tempdir('render', 'twitter')
		file_path = save_copy('render', file_path)
		image = bpy.context.area.spaces.active.image
		image.save_render(filepath=file_path)


		image = open(file_path, 'rb')
		response = twitter.upload_media(media=image)
		twitter.update_status(status=self.message, media_ids=[response['media_id']])
		image.close()

		del_img(file_path)
		if ui.screenpainting:
			bpy.ops.scene.blendshare_screenshot_draw_cancel()
		return {'FINISHED'}

	def invoke(self, context, event):
		self.message=""
		#self.operator(self.bl_idname, text="Text Export Operator")
		return context.window_manager.invoke_props_dialog(self)

class BlendShare_Twitter_Tweet_Screenshot(bpy.types.Operator):
	"""Tweet screenshot"""
	bl_idname = "scene.blendshare_twitter_screenshot"
	bl_label = "Tweet screenshot"
	message = bpy.props.StringProperty(name="Message",description="Message to go along with the tweet", default="",maxlen=116)
	file_path = ""
	def execute(self, context):
		props = bpy.context.scene.blendshare
		from .twython import Twython
		#import json
		json_path = os.path.join(os.path.dirname(__file__), 'user_info', "twitter_tokens.json")
		json_data = {}

		with open(json_path,'r') as infile:
			json_data = json.load(infile)

		keynsecret = twitter_key()
		apk = keynsecret[0]
		aps = keynsecret[1]

		twitter = Twython(apk+ui.twk+'VNEb7rcWK', aps+ui.tws+'FHTrrBHB8JECDS12',
			json_data['TOKEN'], json_data['SECRET'])

		file_path = self.file_path
		file_path = save_copy('screenshot', file_path)

		image = open(file_path, 'rb')
		response = twitter.upload_media(media=image)
		twitter.update_status(status=self.message, media_ids=[response['media_id']])
		image.close()

		del_img(file_path)

		return {'FINISHED'}

	def invoke(self, context, event):
		self.message=""
		props = bpy.context.scene.blendshare
		hidden_screenshot = False
		hidden_render = False

		if props.UI_hide_panels and props.UI_show_screenshot:
			hidden_screenshot = True
			props.UI_show_screenshot = False
		if props.UI_hide_panels and props.UI_show_render:
			hidden_render = True
			props.UI_show_render = False

		file_path = get_tempdir('screenshot', "twitter")
		bpy.ops.screen.screenshot(filepath=file_path)

		if hidden_screenshot:
			props.UI_show_screenshot = True
		if hidden_render:
			props.UI_show_render = True

		self.file_path = file_path

		return context.window_manager.invoke_props_dialog(self)

class BlendShare_Twitter_Tweet_Unlink_Acc(bpy.types.Operator):
	"""Unlink account, BlendShare will no longer be able to post to your twitter account"""
	bl_idname = "scene.blendshare_twitter_unlink_account"
	bl_label = "Unlink twitter account"
	def execute(self, context):

		# Remove Twitter Tokens
		twitter_path = os.path.join(os.path.dirname(__file__),"user_info", "twitter_tokens.json")
		try:
			os.remove(twitter_path)
		except:
			pass

		# Remove linked account
		json_data = {}
		json_path = os.path.join(os.path.dirname(__file__),"user_info", "linked_accounts.json")
		with open(json_path,'r') as infile:
			json_data = json.load(infile)

		json_data["Twitter"] = {"linked_account":""}
		ui.twitter_account = ""

		with open(json_path, 'w') as outfile:
			json.dump(json_data, outfile)

		# Open webbrowser to let user remove Blendshare completely
		bpy.ops.wm.url_open(url="https://twitter.com/settings/applications")

		return {'FINISHED'}


# Gifs
timesave = 0
prev_waittime = 50

def GIF_start_recording(self, context):
	props = bpy.context.scene.blendshare
	bpy.context.scene.blendshare.UI_show_screenshot = False
	import tempfile
	temp_dir = tempfile.gettempdir()

	global prev_waittime
	prev_waittime = bpy.context.user_preferences.system.screencast_wait_time
	bpy.context.user_preferences.system.screencast_wait_time = props.wait_timer

	screencastdir = os.path.join(temp_dir,"Blendshare_Screencast")

	# Clear previous gif if it exists
	try:
		if os.path.exists(screencastdir):
			import shutil
			shutil.rmtree(screencastdir)

		os.makedirs(screencastdir)
	except:
		pass


	screencastdir = os.path.join(screencastdir,"frame")
	global prev_output_path
	prev_output_path = context.scene.render.filepath
	context.scene.render.filepath = screencastdir

	global prev_fileformat
	prev_fileformat = bpy.context.scene.render.image_settings.file_format
	bpy.context.scene.render.image_settings.file_format = 'JPEG'
	ui.GIFs_status = "rec"
	import time
	global timesave
	timesave = time.time()
	bpy.ops.screen.screencast()#filepath="screencastdir"+'test.png')

def GIF_stop_recording(self, context):
	import time
	timesave2 = time.time()
	global timesave

	totaltime = timesave2-timesave


	props = bpy.context.scene.blendshare
	bpy.context.scene.blendshare.UI_show_screenshot = True

	# Stop screencast
	bpy.ops.wm.window_fullscreen_toggle()
	bpy.ops.wm.window_fullscreen_toggle()

	# Get temppath
	import tempfile
	temp_dir = tempfile.gettempdir()
	screencastdir = os.path.join(temp_dir,"Blendshare_Screencast")

	# Create Gif
	from . import imageio
	filenames = os.listdir(screencastdir)
	fps = int((len(filenames)/totaltime)*props.gifs_speed)
	if fps > 49:
		fps = 49
	elif fps < 1:
		fps = 1
	images = []
	for filename in filenames:
		images.append(imageio.imread(os.path.join(screencastdir, filename)))
	gif_path = os.path.join(temp_dir,"Blendershare_Gif.gif")
	imageio.mimsave(gif_path, images, fps=fps)

	# Clear Gif Folder
	try:
		import shutil
		shutil.rmtree(screencastdir)
		pass
	except:
		pass

	# Reset framerate
	global prev_fileformat
	bpy.context.scene.render.image_settings.file_format = prev_fileformat

	# Preview
	if props.gifs_playback:
		try:
			from sys import platform as _platform
			if _platform == "linux" or _platform == "linux2":
				os.system('xdg-open' + gif_path)
			elif _platform == "darwin":
				os.system("open " + gif_path)
			elif _platform == "win32":
				os.system("start " + gif_path)
		except:
			pass
	global prev_output_path
	context.scene.render.filepath = prev_output_path

	global prev_waittime
	bpy.context.user_preferences.system.screencast_wait_time
	ui.GIFs_status = "post"

class Record_Gif(bpy.types.Operator):
	"""Record a GIF"""
	bl_idname = "scene.blendshare_record_gif"
	bl_label = "Record GIF"
	def execute(self, context):
		if ui.GIFs_status == "":
			GIF_start_recording(self, context)
		elif ui.GIFs_status == "rec":
			GIF_stop_recording(self, context)
		return {'FINISHED'}


class Upload_Gif(bpy.types.Operator):
	"""Upload GIF"""
	bl_idname = "scene.blendshare_upload_gif"
	bl_label = "Upload Gif"
	upload_type = bpy.props.StringProperty()
	def execute(self, context):
		import tempfile
		temp_dir = tempfile.gettempdir()
		import time
		filename = "Blendershare_Gif_"+time.strftime("%y-%m-%d %H;%M;%S")+".gif"
		gifdir_old = os.path.join(temp_dir,"Blendershare_Gif.gif")
		gifdir = os.path.join(temp_dir,filename)

		try:
			os.rename(gifdir_old, gifdir)
		except:
			pass

		if self.upload_type != "cancel":
			gifdir = save_copy('screenshot', gifdir)
		if self.upload_type == "imgur":
			try:
				upload_image(self, context, gifdir)
			except:
				self.report({'ERROR'}, 'Failed to upload GIF')
		elif self.upload_type == "dropbox":
			try:
				dropbox_upload(self, context, gifdir)
			except:
				self.report({'ERROR'}, 'Failed to upload GIF')
		elif self.upload_type == "gdrive":
			try:
				gdrive_upload(context, filename, gifdir)
			except:
				self.report({'ERROR'}, 'Failed to upload GIF')

		ui.GIFs_status = ""
		del_img(gifdir)
		return {'FINISHED'}

class BlendShare_Twitter_Tweet_GIF(bpy.types.Operator):
	"""Tweet GIF"""
	bl_idname = "scene.blendshare_twitter_upload_gif"
	bl_label = "Tweet image"
	message = bpy.props.StringProperty(name="Message",description="Message to go along with the tweet", default="",maxlen=116)
	def execute(self, context):
		from .twython import Twython

		#import json
		json_path = os.path.join(os.path.dirname(__file__), 'user_info', "twitter_tokens.json")
		json_data = {}

		import tempfile
		temp_dir = tempfile.gettempdir()
		import time
		gifdir_old = os.path.join(temp_dir,"Blendershare_Gif.gif")
		gifdir = os.path.join(temp_dir,"Blendershare_Gif_"+time.strftime("%y-%m-%d %H;%M;%S")+".gif")
		try:
			os.rename(gifdir_old, gifdir)
		except:
			pass

		with open(json_path,'r') as infile:
			json_data = json.load(infile)

		keynsecret = twitter_key()
		apk = keynsecret[0]
		aps = keynsecret[1]

		twitter = Twython(apk+ui.twk+'VNEb7rcWK', aps+ui.tws+'FHTrrBHB8JECDS12',
			json_data['TOKEN'], json_data['SECRET'])

		gifdir = save_copy('screenshot', gifdir)


		image = open(gifdir, 'rb')
		try:
			response = twitter.upload_media(media=image)
			twitter.update_status(status=self.message, media_ids=[response['media_id']])
		except:
			print("Failed to upload GIF, this could be because: \n"+\
					"1) The GIF is too large, tip: When recording the GIF, make the window smaller, so the gif doesn't become 1080p. \n"+\
					"2) Your internet connection is too slow.")

		image.close()

		del_img(gifdir)

		ui.GIFs_status = ""
		return {'FINISHED'}

	def invoke(self, context, event):
		self.message=""
		return context.window_manager.invoke_props_dialog(self)

def register():
	"register"


def unregister():
	"unregister"
